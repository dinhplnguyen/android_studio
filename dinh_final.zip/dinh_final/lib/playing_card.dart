class PlayingCardH {

  PlayingCardH(this.id, this.value, this.suit);

  final String id;
  final String value;
  final String suit;
}